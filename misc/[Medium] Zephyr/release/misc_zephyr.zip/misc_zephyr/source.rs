#[macro_use] extern crate lazy_static;
use std::io;
use std::io::Write;
use std::env;
use std::sync::Mutex;
use rusqlite::{Connection};


lazy_static! {
    static ref DB_CONN: Mutex<Connection> = Mutex::new(Connection::open("database.db").unwrap());
}

const MENU: &str = "MI6: Admin Panel\n\n1) Add Users\n2) View Users\n3) Delete Users\n4) Quit";

fn main() {
    let admin_password: String = env::var("ADMIN_PASS").expect("Admin Password not set!");

    print!("Enter the administrator password: ");
    io::stdout().flush().unwrap();

    let mut input = String::new();
    io::stdin()
        .read_line(&mut input)
        .expect("Failed to read password");

    if input.trim() != admin_password {
        eprintln!("Password invalid!");
        std::process::exit(-1);
    }

    input.clear();

    println!("{}\n", MENU);

    loop {
        print!("> ");
        io::stdout().flush().unwrap();

        io::stdin()
            .read_line(&mut input)
            .expect("Failed to read line");

        let number: i32 = input.trim().parse().unwrap_or_else(|_| {
            eprintln!("Please enter a valid integer!");
            return 5;
        });

        match number {
            1 => add_user(),
            2 => view_users(),
            3 => delete_user(),
            4 => break,
            _ => println!("Invalid choice, please try again!")
        }
    }
}

fn add_user() {
    print!("Username: ");
    io::stdout().flush().unwrap();

    let mut username = String::new();

    io::stdin()
        .read_line(&mut username)
        .expect("Failed to read line");

    let username = username.trim();

    print!("Password: ");
    io::stdout().flush().unwrap();

    let mut password = String::new();

    io::stdin()
        .read_line(&mut password)
        .expect("Failed to read line");

    let password = password.trim();

    let conn = DB_CONN.lock().unwrap();

    conn.execute("INSERT INTO users (username, password) VALUES (?1, ?2);", &[&username, &password])
        .expect("Failed to create user!");
}

fn view_users() {
    let conn = DB_CONN.lock().unwrap();
    let mut stmt = conn.prepare("SELECT id, username, password FROM users;")
        .expect("Failed to prepare a statement");
    let mut rows = stmt.query([])
        .expect("Error getting users");

    while let Ok(Some(row)) = rows.next() {
        let id: i32 = row.get::<_, i32>(0).expect("Parsing ID failed!");
        let username: String = row.get::<_, String>(1).expect("Parsing username failed!");
        let password: String = row.get::<_, String>(2).expect("Parsing password failed!");

        println!("ID {}: {}\t{}", id, username, password);
    };
}

fn delete_user() {
    let conn = DB_CONN.lock().unwrap();

    print!("Enter ID: ");
    io::stdout().flush().unwrap();

    let mut input = String::new();
    io::stdin()
        .read_line(&mut input)
        .expect("Failed to read line");

    let number: i32 = match input.trim().parse() {
        Ok(num) => num,
        Err(_) => {
            eprintln!("Please enter a valid integer!");
            return;
        }
    };

    conn.execute("DELETE FROM users WHERE id=?1;", &[&number])
        .expect("Failed to delete user!");
}

