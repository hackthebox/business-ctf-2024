"Location - Red Sands Stronghold, Coordinates - 34°N, 115°W, Region - Western Wastes, Camp Strength - 200, Reserve - 50."



"Location - Crater Valley Camp, Coordinates - 22°S, 43°W, Region - Southern Highlands, Camp Strength - 150, Reserve - 30."



"Location - Blackwater Marsh, Coordinates - 45°N, 122°W, Region - Northern Marshlands, Camp Strength - 300, Reserve - 70."



"Location - Echo Caves Network, Coordinates - 47°N, 11°E, Region - Alpine Ridge, Camp Strength - 100, Reserve - 20."



"Location - Frostbite Falls, Coordinates - 60°N, 96°W, Region - Arctic Frontier, Camp Strength - 180, Reserve - 40."



"Location - Dustwind Plateau, Coordinates - 39°N, 104°W, Region - Central Plateau, Camp Strength - 120, Reserve - 25."



"Location - Ruined Metropolis, Coordinates - 51°N, 0°W, Region - Urban Ruins, Camp Strength - 500, Reserve - 100."



"Location - Neon Jungle, Coordinates - 3°S, 60°W, Region - Amazonian Expanse, Camp Strength - 250, Reserve - 50."



"Location - Twilight Canyon, Coordinates - 36°N, 112°W, Region - Canyon Lands, Camp Strength - 140, Reserve - 30."



"Location - Whispering Pines, Coordinates - 54°N, 5°E, Region - Northern Pine Forest, Camp Strength - 160, Reserve - 35."



"Location - Scorched Earth Plains, Coordinates - 40°S, 74°W, Region - Southern Deserts, Camp Strength - 400, Reserve - 80."



"Location - Quantum Falls, Coordinates - 42°N, 74°W, Region - Northeastern Highlands, Camp Strength - 130, Reserve - 20."



"Location - Dead Man’s Bluff, Coordinates - 50°N, 2°W, Region - Coastal Cliffs, Camp Strength - 80, Reserve - 10."



"Location - Ironwood Bastion, Coordinates - 37°N, 78°W, Region - Eastern Woodlands, Camp Strength - 220, Reserve - 45."



"Location - Radiant Bay, Coordinates - 29°N, 90°W, Region - Gulf Coast, Camp Strength - 280, Reserve - 60."



"List of all the mutant camps - Western Wastes, Southern Highlands, Northern Marshlands, Alpine Ridge, Arctic Frontier, Central Plateau, Urban Ruins, Amazonian Expanse, Canyon Lands, Northern Pine Forest, Southern Deserts, Northeastern Highlands, Coastal Cliffs, Eastern Woodlands, and Gulf Coast."
