"mutant Energy Weapons list: Voltcaster, Graviton Beam, Prism Laser."



"mutant Melee and Close Combat Weapons list: Pulsar Hammer, Phantom Blade, Titan Grip."



"mutant bomb and Area Denial Weapons list: Galeforce Launcher, Starfall Bomb, Inferno Stream."



"mutant Tactical and Trap Weapons list: Quantum Snare, Thunderclap Mine, Frost Net."



"mutant Specialty and High-Tech Weapons list: CryoCannon, Shadow Streak, Void Sphere, Singularity Bomb."



"mutant Stealth and Assassination Weapons list: Phantom Blade, Razorwind Disc, Venom Dart."



"mutant Biological and Chemical Weapons list: Venom Dart."



"mutant Magical and Exotic Weapons list: Oblivion Wand, Void Sphere."



"mutant Long Range Weapons list: Voltcaster, Shadow Streak, Arcanite Railgun."



"mutant Disruption and Control Weapons list: Echo Pulse, Siren Howler, Mirage Projector."



"Weapon-name: Voltcaster, Type: Energy Rifle, Weapon-range: Long, Known-for: Sniping through energy shields, Handling-difficulty: Moderate, Production-cost: High."



"Weapon-name: Pulsar Hammer, Type: Melee, Weapon-range: Close, Known-for: Demolishing armored vehicles, Handling-difficulty: Hard, Production-cost: Medium."



"Weapon-name: Phantom Blade, Type: Stealth Knife, Weapon-range: Close, Known-for: Silent assassinations, Handling-difficulty: Easy, Production-cost: Low."



"Weapon-name: Galeforce Launcher, Type: Rocket Launcher, Weapon-range: Long, Known-for: Wide-area suppression, Handling-difficulty: Hard, Production-cost: High."



"Weapon-name: Quantum Snare, Type: Trap, Weapon-range: Close, Known-for: Capturing high-speed targets, Handling-difficulty: Moderate, Production-cost: Medium."



"Weapon-name: CryoCannon, Type: Cannon, Weapon-range: Medium, Known-for: Crowd control with freeze effects, Handling-difficulty: Moderate, Production-cost: Medium."



"Weapon-name: Shadow Streak, Type: Sniper Rifle, Weapon-range: Very Long, Known-for: Piercing through walls, Handling-difficulty: Hard, Production-cost: High."



"Weapon-name: Magma Burst, Type: Grenade, Weapon-range: Close, Known-for: Incinerating bunkers, Handling-difficulty: Easy, Production-cost: Low."



"Weapon-name: Echo Pulse, Type: Shotgun, Weapon-range: Short, Known-for: Disorienting enemies with sound waves, Handling-difficulty: Easy, Production-cost: Low."



"Weapon-name: Graviton Beam, Type: Energy Gun, Weapon-range: Medium, Known-for: Manipulating enemy positions, Handling-difficulty: Moderate, Production-cost: High."



"Weapon-name: Oblivion Wand, Type: Magic Staff, Weapon-range: Long, Known-for: Draining life force, Handling-difficulty: Hard, Production-cost: Very High."



"Weapon-name: Neutron Whip, Type: Energy Whip, Weapon-range: Medium, Known-for: Multi-target attacks, Handling-difficulty: Moderate, Production-cost: Medium."



"Weapon-name: Razorwind Disc, Type: Throwing Weapon, Weapon-range: Medium, Known-for: Returning to sender, Handling-difficulty: Moderate, Production-cost: Low."



"Weapon-name: Thunderclap Mine, Type: Landmine, Weapon-range: Close, Known-for: Electromagnetic pulse generation, Handling-difficulty: Easy, Production-cost: Medium."



"Weapon-name: Siren Howler, Type: Rifle, Weapon-range: Long, Known-for: Causing disarray in enemy ranks, Handling-difficulty: Moderate, Production-cost: Medium."



"Weapon-name: Starfall Bomb, Type: Aerial Bomb, Weapon-range: Very High (Dropped from aircraft), Known-for: Area denial, Handling-difficulty: Easy, Production-cost: High."



"Weapon-name: Void Sphere, Type: Orb, Weapon-range: Close, Known-for: Creating temporary black holes, Handling-difficulty: Hard, Production-cost: Very High."



"Weapon-name: Inferno Stream, Type: Flamethrower, Weapon-range: Short, Known-for: Clearing entrenched positions, Handling-difficulty: Easy, Production-cost: Low."



"Weapon-name: Prism Laser, Type: Laser Rifle, Weapon-range: Long, Known-for: Precision targeting, Handling-difficulty: Moderate, Production-cost: Medium."



"Weapon-name: Titan Grip, Type: Exoskeleton Arm, Weapon-range: Close, Known-for: Enhancing physical attacks, Handling-difficulty: Moderate, Production-cost: High."



"Weapon-name: Frost Net, Type: Net Gun, Weapon-range: Short, Known-for: Immobilizing and freezing targets, Handling-difficulty: Easy, Production-cost: Low."



"Weapon-name: Singularity Bomb, Type: Explosive, Weapon-range: Medium, Known-for: Generating gravity wells, Handling-difficulty: Hard, Production-cost: High."



"Weapon-name: Mirage Projector, Type: Holographic Device, Weapon-range: Close, Known-for: Creating decoys, Handling-difficulty: Easy, Production-cost: Medium."



"Weapon-name: Arcanite Railgun, Type: Railgun, Weapon-range: Very Long, Known-for: Penetrating heavy armor, Handling-difficulty: Hard, Production-cost: High."



"Weapon-name: Venom Dart, Type: Dart Gun, Weapon-range: Medium, Known-for: Poisoning targets silently, Handling-difficulty: Easy, Production-cost: Low."