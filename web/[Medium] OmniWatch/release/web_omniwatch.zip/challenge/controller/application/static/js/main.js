window.onload = () => {
    setTimeout(() => {
        document.getElementById("loadingSection").classList.add("hide");
    }, 3000);
}