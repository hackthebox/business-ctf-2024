<?php
class Controller {
    public function __construct()
    {
        $this->router = new Router();
    }
}
?>