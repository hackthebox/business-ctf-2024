<?php require 'views/partial/header.php'; ?>
<body>
    <div class="container mt-5">
        <p class>Nothing here...</p>
    </div>
<?php require 'views/partial/footer.php'; ?>