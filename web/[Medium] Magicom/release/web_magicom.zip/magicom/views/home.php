<?php require 'views/partial/header.php'; ?>
<div class="container mt-5">
    <h1>Magicom - Magical Platform</h1>
    <img class="mt-5" src="https://i.kym-cdn.com/photos/images/original/002/068/727/177.jpg" alt="Trade Offer">
</div>
<?php require 'views/partial/footer.php'; ?>